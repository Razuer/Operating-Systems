import java.util.Comparator;

public class processNameComparator implements Comparator<Process> {
    @Override
    public int compare(Process o1, Process o2) {
        return o1.getName()-o2.getName();
    }
}
