import java.util.Comparator;

public class processSizeComparator implements Comparator<Process> {
    @Override
    public int compare(Process o1, Process o2) {
        return o2.getPages().size() - o1.getPages().size();
    }
}
