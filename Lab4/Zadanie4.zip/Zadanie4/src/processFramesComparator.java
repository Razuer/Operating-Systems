import java.util.Comparator;

public class processFramesComparator implements Comparator<Process> {
    @Override
    public int compare(Process o1, Process o2) {
        return o1.getFramesAcquired()-o2.getFramesAcquired();
    }
}

